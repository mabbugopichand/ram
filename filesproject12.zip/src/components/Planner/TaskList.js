import React, { useState, useEffect } from "react";
import { db } from "../../utils/firebase";
import { collection, addDoc, getDocs } from "firebase/firestore";

const TaskList = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");

  useEffect(() => {
    const fetchTasks = async () => {
      const querySnapshot = await getDocs(collection(db, "tasks"));
      const tasksData = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTasks(tasksData);
    };

    fetchTasks();
  }, []);

  const addTask = async () => {
    try {
      const docRef = await addDoc(collection(db, "tasks"), {
        task: newTask,
        completed: false,
      });
      setTasks((prev) => [...prev, { id: docRef.id, task: newTask, completed: false }]);
      setNewTask("");
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div>
      <h2>Tasks</h2>
      <ul>
        {tasks.map((task) => (
          <li key={task.id}>
            {task.task} {task.completed ? "✅" : ""}
          </li>
        ))}
      </ul>
      <input
        type="text"
        placeholder="New Task"
        value={newTask}
        onChange={(e) => setNewTask(e.target.value)}
      />
      <button onClick={addTask}>Add Task</button>
    </div>
  );
};

export default TaskList;