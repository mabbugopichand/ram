import React, { useState } from "react";

const DistractionLog = () => {
  const [distraction, setDistraction] = useState("");

  const logDistraction = () => {
    console.log(`Distraction: ${distraction}`);
    setDistraction("");
  };

  return (
    <div>
      <h2>Distraction Log</h2>
      <input
        type="text"
        placeholder="What distracted you?"
        value={distraction}
        onChange={(e) => setDistraction(e.target.value)}
      />
      <button onClick={logDistraction}>Log Distraction</button>
    </div>
  );
};

export default DistractionLog;