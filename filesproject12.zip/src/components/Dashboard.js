import React from "react";
import TaskList from "./Planner/TaskList";
import StudyLogger from "./Tracker/StudyLogger";
import DistractionLog from "./Reflection/DistractionLog";

const Dashboard = () => {
  return (
    <div>
      <h1>Productivity Dashboard</h1>
      <TaskList />
      <StudyLogger />
      <DistractionLog />
    </div>
  );
};

export default Dashboard;