import React, { useState } from "react";

const StudyLogger = () => {
  const [subject, setSubject] = useState("");
  const [hours, setHours] = useState("");

  const logStudyTime = () => {
    console.log(`Studied ${subject} for ${hours} hours.`);
    setSubject("");
    setHours("");
  };

  return (
    <div>
      <h2>Study Logger</h2>
      <input
        type="text"
        placeholder="Subject"
        value={subject}
        onChange={(e) => setSubject(e.target.value)}
      />
      <input
        type="number"
        placeholder="Hours"
        value={hours}
        onChange={(e) => setHours(e.target.value)}
      />
      <button onClick={logStudyTime}>Log Study Time</button>
    </div>
  );
};

export default StudyLogger;