#!/bin/bash

# Create the LXC container
lxc-create -n flask-app -t download -- --dist ubuntu --release focal --arch amd64

# Copy the application files
cp -r /path/to/app /var/lib/lxc/flask-app/rootfs/app

# Start the LXC container
lxc-start -n flask-app