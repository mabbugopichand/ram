#!/bin/bash

# Pull the latest changes from the Git repository
git pull origin main

# Restart Docker container
docker build -t flask-app .
docker stop flask-app
docker rm flask-app
docker run -d -p 5000:5000 --name flask-app flask-app

# Restart LXC container
lxc-stop -n flask-app
cp -r /path/to/app /var/lib/lxc/flask-app/rootfs/app
lxc-start -n flask-app