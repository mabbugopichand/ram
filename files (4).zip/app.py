from flask import Flask

app = Flask(__name__)

# Application version
VERSION = "1.0.0"

@app.route("/")
def home():
    return f"Hello, this is version {VERSION}!"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)